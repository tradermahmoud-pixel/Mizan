@echo off
cd /d "%~dp0"
if not exist "%~dp0run.bat" (echo Put these files in the Mizan agent folder & pause & exit /b 1)
echo Setting up the background fast writer (no admin needed)...
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $p=[Environment]::GetFolderPath('Startup')+'\MizanOrgaWrite.lnk'; $s=$w.CreateShortcut($p); $s.TargetPath='wscript.exe'; $s.Arguments='\"%~dp0watch.vbs\"'; $s.WorkingDirectory='%~dp0'; $s.Save()"
if errorlevel 1 (echo Could not add to Startup. & pause & exit /b 1)
echo Added to Startup (auto-starts when you log in).
wscript "%~dp0watch.vbs"
echo.
echo Done. The fast writer is running now in the background (hidden).
echo Queued purchases will write within about 12 seconds.
pause
