'use strict';
/* برنامج ربط أورجا ← ميزان
   - بيقرا ORGA.GDB من سيرفر Firebird اللي على الجهاز، بمستخدم «قراءة بس» وفي transaction للقراءة بس.
   - مش بينسخ الملف ولا بيكتب فيه أي حاجة.
   - بيقارن باللي اتبعت آخر مرة (state.json) ويبعت اللي اتغيّر بس لميزان على HTTPS بمفتاح الربط.
   الأوامر:
     node agent.js setup     إعداد أول مرة (رابط ميزان + مفتاح الربط + مكان ORGA.GDB + إنشاء مستخدم القراءة)
     node agent.js           مزامنة مرة واحدة (المهمة المجدولة بتشغّله كل 5 دقايق)
     node agent.js test      اختبار الاتصال بأورجا وبميزان من غير ما يبعت حاجة
     node agent.js reset     يمسح ذاكرة آخر مزامنة (المرة الجاية هيقارن كل السجلات من الأول) */
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const fb = require('node-firebird');
const iconv = require('iconv-lite');
const { mapAll, KEYS, TABLES } = require('./lib/map');
const { writePurchase } = require('./lib/orgawrite');

const VER = '1.4.0';
const DIR = __dirname;
const CFG = path.join(DIR, 'config.json');
const STATE = path.join(DIR, 'state.json');
const LOCK = path.join(DIR, 'sync.lock');
const LOGD = path.join(DIR, 'logs');
const RO_USER = 'MIZAN_RO';
const COLS = [['safes', 'safes'], ['products', 'x_products'], ['parties', 'x_parties'], ['invoices', 'x_invoices'], ['cash', 'x_cash']];
const BATCH_ITEMS = 1500, BATCH_BYTES = 6 * 1024 * 1024;

/* ---------- log ---------- */
function log(...a) {
  const d = new Date(), p2 = n => String(n).padStart(2, '0');
  const line = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}  ` + a.join(' ');
  console.log(line);
  try {
    fs.mkdirSync(LOGD, { recursive: true });
    const f = path.join(LOGD, 'agent.log');
    try { if (fs.statSync(f).size > 2e6) fs.renameSync(f, path.join(LOGD, 'agent.old.log')); } catch (e) {}
    fs.appendFileSync(f, line + os.EOL);
  } catch (e) {}
}

/* ---------- حماية الأسرار (Windows DPAPI — المفتاح المتشفّر مينفعش يتفك على جهاز تاني) ---------- */
const WIN = process.platform === 'win32';
function ps(script, input) {
  return execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { input, encoding: 'utf8', windowsHide: true }).trim();
}
function protect(s) {
  if (!WIN) return 'plain:' + Buffer.from(s).toString('base64');
  const out = ps("Add-Type -AssemblyName System.Security; $b=[Text.Encoding]::UTF8.GetBytes([Console]::In.ReadToEnd()); [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($b,$null,'LocalMachine'))", s);
  return 'dpapi:' + out;
}
function unprotect(v) {
  if (!v) return '';
  if (v.startsWith('plain:')) return Buffer.from(v.slice(6), 'base64').toString();
  if (v.startsWith('dpapi:')) return ps("Add-Type -AssemblyName System.Security; $b=[Convert]::FromBase64String([Console]::In.ReadToEnd().Trim()); [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($b,$null,'LocalMachine'))", v.slice(6));
  throw new Error('Unknown secret format in config.json - run setup.bat again');
}

/* ---------- إعدادات ---------- */
function loadCfg() {
  if (!fs.existsSync(CFG)) throw new Error('Not set up yet - run setup.bat first (Run as administrator)');
  const c = JSON.parse(fs.readFileSync(CFG, 'utf8'));
  return { ...c, token: unprotect(c.token), dbPass: unprotect(c.dbPass), dbWritePass: c.dbWritePass ? unprotect(c.dbWritePass) : '' };
}
function saveCfg(c) {
  // الحفاظ على إعدادات الكتابة لو مش جاية في c (علشان إعادة setup ماتمسحهاش)
  let prev = {}; try { prev = JSON.parse(fs.readFileSync(CFG, 'utf8')); } catch (e) {}
  const out = { url: c.url, dbHost: c.dbHost, dbPort: c.dbPort, dbPath: c.dbPath, dbUser: c.dbUser, token: protect(c.token), dbPass: protect(c.dbPass), createdAt: new Date().toISOString() };
  const orgaWrite = c.orgaWrite !== undefined ? c.orgaWrite : prev.orgaWrite;
  if (orgaWrite) out.orgaWrite = true;
  const wUser = c.dbWriteUser !== undefined ? c.dbWriteUser : prev.dbWriteUser;
  if (wUser) out.dbWriteUser = wUser;
  if (c.dbWritePass) out.dbWritePass = protect(c.dbWritePass);
  else if (c.dbWriteUser === undefined && prev.dbWritePass) out.dbWritePass = prev.dbWritePass;
  fs.writeFileSync(CFG, JSON.stringify(out, null, 2));
  if (WIN) { try { execFileSync('icacls', [CFG, '/inheritance:r', '/grant:r', '*S-1-5-18:F', '*S-1-5-32-544:F'], { windowsHide: true, stdio: 'ignore' }); } catch (e) {} }
  else { try { fs.chmodSync(CFG, 0o600); } catch (e) {} }
}

/* ---------- Firebird (قراءة بس) ---------- */
const attach = o => new Promise((res, rej) => fb.attach({ host: o.host, port: o.port, database: o.database, user: o.user, password: o.password, encoding: 'NONE', lowercase_keys: false, role: null, pageSize: 4096 }, (e, db) => e ? rej(e) : res(db)));
const q = (tx, s, p = []) => new Promise((res, rej) => tx.query(s, p, (e, r) => e ? rej(e) : res(r)));
const detach = db => new Promise(res => { try { db.detach(() => res()); } catch (e) { res(); } });

async function readOrga(c) {
  const db = await attach({ host: c.dbHost, port: c.dbPort, database: c.dbPath, user: c.dbUser, password: c.dbPass });
  try {
    const tx = await new Promise((res, rej) => db.transaction({ isolation: fb.ISOLATION_REPEATABLE_READ, readOnly: true, wait: false } /* لقطة ثابتة + قراءة بس */, (e, t) => e ? rej(e) : res(t)));
    const T = {};
    try {
      for (const t of TABLES) {
        const cols = await q(tx, `select trim(rf.rdb$field_name) as N, f.rdb$field_type as T, f.rdb$field_length as LEN from rdb$relation_fields rf join rdb$fields f on f.rdb$field_name=rf.rdb$field_source where rf.rdb$relation_name=? order by rf.rdb$field_position`, [t]);
        if (!cols.length) { T[t] = []; continue; }
        // النصوص في أورجا متخزنة Windows-1256 من غير charset → بنقراها bytes ونفكها
        const sel = cols.filter(x => x.T !== 261).map(x => [14, 37].includes(x.T) ? `CAST("${x.N}" AS VARCHAR(${Math.max(1, x.LEN)}) CHARACTER SET OCTETS) AS "${x.N}"` : [12, 13, 35].includes(x.T) ? `CAST("${x.N}" AS VARCHAR(30)) AS "${x.N}"` : `"${x.N}"`).join(',');
        const rows = await q(tx, `select ${sel} from "${t}"`);
        T[t] = rows.map(r => { const o = {}; for (const k in r) { let v = r[k]; if (Buffer.isBuffer(v)) v = iconv.decode(v, 'win1256'); o[k] = v; } return o; });
      }
    } finally { await new Promise(res => tx.commit(() => res())); }
    return T;
  } finally { await detach(db); }
}

function fbErr(e) {
  const m = String(e && e.message || e);
  if (/ECONNREFUSED|connect/i.test(m) && !/password|user name/i.test(m)) return 'No Firebird server is running on this host/port. Orga must run with a Firebird server (not embedded). Details: ' + m;
  if (/password|user name/i.test(m)) return 'Wrong Firebird user name or password';
  if (/I\/O error|open|No such file/i.test(m)) return 'Cannot open the Orga database file - check the path. Details: ' + m;
  return m;
}

/* ---------- ميزان ---------- */
async function api(c, p, body) {
  const r = await fetch(c.url.replace(/\/+$/, '') + p, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Mizan': '1', Authorization: 'Bearer ' + c.token },
    body: JSON.stringify({ ...body, agent: { ver: VER, host: os.hostname() } }), signal: AbortSignal.timeout(120e3),
  });
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) {
    const msg = r.status === 401 ? 'Mizan rejected the sync key (wrong or revoked). Create a new key in Mizan: Settings > Orga link, then run setup.bat again'
      : r.status === 409 && j && j.code === 'mass_delete' ? 'Mizan refused a mass delete for safety'
      : r.status === 429 ? 'Too many requests - will retry next run'
      : r.status === 400 ? 'Mizan rejected the data: ' + ((j && j.error) || '')
      : 'Mizan error HTTP ' + r.status;
    throw Object.assign(new Error(msg), { status: r.status, code: j && j.code });
  }
  return j;
}

/* ---------- مقارنة ---------- */
const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
const stable = v => Array.isArray(v) ? '[' + v.map(stable).join(',') + ']' : isObj(v) ? '{' + Object.keys(v).filter(k => v[k] != null).sort().map(k => JSON.stringify(k) + ':' + stable(v[k])).join(',') + '}' : JSON.stringify(v === undefined ? null : v);
const hash = v => crypto.createHash('sha1').update(stable(v)).digest('base64').slice(0, 16);
const pick = (v, ks) => { const o = {}; for (const k of ks) if (v[k] !== undefined) o[k] = v[k]; return o; };
function loadState() { try { return JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch (e) { return { v: 1, h: {} }; } }
function saveState(s) { const t = STATE + '.tmp'; fs.writeFileSync(t, JSON.stringify(s)); fs.renameSync(t, STATE); }

async function sync(dry) {
  const c = loadCfg();
  if (!/^https:\/\//.test(c.url) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?/.test(c.url)) throw new Error('Mizan URL must start with https://');
  const t0 = Date.now();
  const T = await readOrga(c).catch(e => { throw new Error(fbErr(e)); });
  const M = mapAll(T);
  log('Read Orga in', ((Date.now() - t0) / 1000).toFixed(1) + 's:', COLS.map(([k, x]) => k + '=' + Object.keys(M[x]).length).join(' '));
  if (dry) { await api(c, '/api/orga/ping', {}); log('Connection to Mizan OK'); return; }
  const st = loadState(); const tot = { up: 0, del: 0 };
  // مرة كل يوم: مراجعة كاملة — بيبعت كل السجلات وميزان بيكتب المختلف بس (بيصلّح أي سجل أورجا اتعدّل في ميزان بالغلط)
  const full = !st.fullAt || !st.manifestAt || Date.now() - st.fullAt > 24 * 3600e3;
  if (full) log('Daily full check');
  for (const [col, x] of COLS) {
    const prev = st.h[col] || {}; const cur = {}; const up = []; const del = [];
    for (const [id, v0] of Object.entries(M[x])) { const v = pick(v0, KEYS[col]); const h = hash(v); cur[id] = h; if (full || prev[id] !== h) up.push([id, v, h]); }
    for (const id of Object.keys(prev)) if (!(id in cur)) del.push(id);
    // أمان: لو أورجا رجعت فاضية أو نص السجلات اختفت فجأة → مفيش حذف (غالبًا ملف غلط أو قراءة ناقصة)
    const nPrev = Object.keys(prev).length;
    if (del.length && (Object.keys(cur).length === 0 || del.length > Math.max(30, nPrev * 0.02))) { log(`WARNING ${col}: ${del.length} records disappeared from Orga - deletes skipped for safety (check the database path, or run: run.bat reset)`); del.length = 0; }
    if (!up.length && !del.length) continue;
    // بالدفعات
    let i = 0;
    while (i < up.length || del.length) {
      const part = []; let bytes = 0;
      while (i < up.length && part.length < BATCH_ITEMS && bytes < BATCH_BYTES) { const s = JSON.stringify(up[i][1]).length; if (part.length && bytes + s > BATCH_BYTES) break; part.push(up[i]); bytes += s; i++; }
      const dl = i >= up.length ? del.splice(0, 1000) : [];
      const r = await api(c, '/api/orga/push', { col, keys: KEYS[col], up: Object.fromEntries(part.map(([id, v]) => [id, v])), del: dl });
      for (const [id, , h] of part) prev[id] = h;
      for (const id of dl) delete prev[id];
      st.h[col] = prev; saveState(st);
      tot.up += r.written || 0; tot.del += r.deleted || 0;
      log(`${col}: sent ${part.length}${dl.length ? ' + delete ' + dl.length : ''} -> written ${r.written || 0}, unchanged ${r.same || 0}${r.kept ? ', protected (Mizan records) ' + r.kept : ''}`);
    }
  }
  if (full) {
    // قايمة كل سجلات أورجا الحالية — ميزان بيستخدمها لو المالك اختار «ميزان = أورجا بس»
    for (const [col, x] of COLS) await api(c, '/api/orga/manifest', { col, ids: Object.keys(M[x]) });
    st.fullAt = st.manifestAt = Date.now(); saveState(st); log('Sent the full list of Orga records to Mizan');
  }
  if (!tot.up && !tot.del) await api(c, '/api/orga/ping', {});
  log(`Sync done in ${((Date.now() - t0) / 1000).toFixed(1)}s - updated ${tot.up}, deleted ${tot.del}`);
  // ميزان ← أورجا: كتابة فواتير الشراء المعلّقة (لو الخاصية متفعّلة)
  try { await writeOutbox(c); } catch (e) { log('Orga write step error: ' + (e.message || e)); }
}

/* ---------- ميزان ← أورجا: كتابة فواتير الشراء ---------- */
// بياخد الفواتير المعلّقة من ميزان، يكتبها في أورجا (ORDER_H+ORDER_D) «مفتوحة»، ويبلّغ ميزان بالنتيجة.
// متقفلة بـ config.orgaWrite=true، وبتستخدم مستخدم كتابة منفصل (dbWriteUser/dbWritePass).
async function writeOutbox(c) {
  if (!c.orgaWrite) return;
  if (!c.dbWriteUser || !c.dbWritePass) { log('Orga write is ON but no write user is set (run: run.bat writesetup) - skipped'); return; }
  let jobs = [];
  try { const r = await api(c, '/api/orga/outbox', {}); jobs = (r && r.jobs) || []; }
  catch (e) { if (e.status !== 404) log('Could not fetch write queue: ' + (e.message || e)); return; }
  if (!jobs.length) return;
  log(`Orga write: ${jobs.length} purchase invoice(s) queued`);
  const conn = { host: c.dbHost, port: c.dbPort, database: c.dbPath, user: c.dbWriteUser, password: c.dbWritePass };
  const results = [];
  for (const j of jobs) {
    try {
      const res = await writePurchase(fb, conn, {
        account: j.account, store: j.store, usersId: j.usersId, usersName: j.usersName, mark: j.mark, lines: j.lines,
      }, { commit: true });
      results.push({ jobId: j.id, ok: true, orderHId: res.orderHId, accHId: res.accHId });
      log(`  wrote queue#${j.id} -> Orga ORDER_H #${res.orderHId} (${(j.lines || []).length} line/s)`);
    } catch (e) {
      results.push({ jobId: j.id, ok: false, error: String(e.message || e).slice(0, 300) });
      log(`  FAILED queue#${j.id}: ${e.message || e}`);
    }
  }
  try { await api(c, '/api/orga/outbox/done', { results }); }
  catch (e) { log('Could not report write results to Mizan: ' + (e.message || e)); }
}

/* اختبار الكتابة على نسخة تجريبية: node agent.js writetest "C:\\ORGA_TEST\\DATA\\ORGA.GDB" [--commit] */
async function writeTest(dbPath, doCommit) {
  dbPath = dbPath || 'C:\\ORGA_TEST\\DATA\\ORGA.GDB';
  if (!/ORGA_TEST/i.test(dbPath)) { console.log('[STOP] For safety the test path must contain ORGA_TEST. Got: ' + dbPath); return; }
  const conn = { host: '127.0.0.1', port: 3050, database: dbPath, user: 'SYSDBA', password: 'masterkey' };
  console.log('Write test on TEST db: ' + dbPath + (doCommit ? '  (COMMIT)' : '  (rollback)'));
  // نجيب مورّد وصنف حقيقيين من نفس الداتا
  const db = await attach(conn);
  let account, store = 1, prod, cost, consumer, usersId = 1;
  try {
    const tx = await new Promise((res, rej) => db.transaction(fb.ISOLATION_READ_COMMITTED, (e, t) => e ? rej(e) : res(t)));
    try {
      const h = await q(tx, `SELECT FIRST 1 ACCOUNT_ID, STORE_ID FROM ORDER_H WHERE ACCOUNT_ID IS NOT NULL ORDER BY ORDER_H_ID DESC`);
      account = h[0].ACCOUNT_ID; store = h[0].STORE_ID || 1;
      const d = await q(tx, `SELECT FIRST 1 PROD_ID, COST, CONSUMER FROM ORDER_D WHERE PROD_ID IS NOT NULL ORDER BY ORDER_D_ID DESC`);
      prod = d[0].PROD_ID; cost = +d[0].COST || 1; consumer = +d[0].CONSUMER || cost;
      const u = await q(tx, `SELECT FIRST 1 USERS_ID FROM USERS`); if (u.length) usersId = u[0].USERS_ID;
    } finally { await new Promise(res => tx.rollback(() => res())); }
  } finally { await detach(db); }
  console.log(`Using supplier=${account}, product=${prod}, qty=2, cost=${cost}`);
  const res = await writePurchase(fb, conn, {
    account, store, usersId, usersName: 'MIZAN', mark: '[MZ#TEST]',
    lines: [{ prod, qty: 2, cost, consumer, expire: '2027-12-31' }],
  }, { commit: !!doCommit });
  console.log(`[ok] write ${res.committed ? 'COMMITTED' : 'rolled back'} -> ORDER_H #${res.orderHId}, ACC_H_ID ${res.accHId}, lines ${res.lineIds.join(',')}`);
  if (res.committed) {
    const db2 = await attach(conn);
    try {
      const tx = await new Promise((r2, j2) => db2.transaction({ isolation: fb.ISOLATION_READ_COMMITTED, readOnly: true }, (e, t) => e ? j2(e) : r2(t)));
      try {
        const hh = await q(tx, `SELECT ORDER_H_ID, CLOSE_, COUNT_PROD, TOTAL_TOTAL, CAST(NOTS_ AS VARCHAR(60) CHARACTER SET OCTETS) NOTS_ FROM ORDER_H WHERE ORDER_H_ID=?`, [res.orderHId]);
        const stk = await q(tx, `SELECT SUM(TOTAL_QTY_ALL) S FROM STOCK_STOCK WHERE PROD_ID=? AND STORE_ID=?`, [prod, store]);
        const h = hh[0];
        console.log(`Read back: CLOSE_=${h.CLOSE_} (0=open), COUNT_PROD=${h.COUNT_PROD}, TOTAL_TOTAL=${h.TOTAL_TOTAL}, NOTS_=${Buffer.isBuffer(h.NOTS_) ? h.NOTS_.toString('latin1') : h.NOTS_}`);
        console.log(`Stock for product now: ${stk[0].S}`);
        console.log('\nThe invoice is OPEN in Orga. Open it there, review, and close it to post the supplier balance.');
      } finally { await new Promise(r3 => tx.commit(() => r3())); }
    } finally { await detach(db2); }
  }
}

/* تفعيل الكتابة الحقيقية: node agent.js writesetup */
async function writeSetup() {
  const c = loadCfg();
  const rl = lineReader();
  try {
    console.log('\n=== Enable writing purchase invoices into Orga ===');
    console.log('This lets Mizan write OPEN purchase invoices into the LIVE Orga database: ' + c.dbPath);
    console.log('They enter as OPEN (draft). Stock moves immediately (Orga behaviour); the supplier');
    console.log('balance is posted only when someone closes the invoice inside Orga.\n');
    const on = (await ask(rl, 'Turn Orga write ON? y/n', 'n')).toLowerCase().startsWith('y');
    if (!on) { saveCfg({ ...c, orgaWrite: false }); console.log('Orga write is OFF. Queued invoices will NOT be written.'); return; }
    const wUser = clean(await ask(rl, 'Firebird user that can WRITE (needs INSERT on ORDER_H/ORDER_D and the tables its triggers touch)', 'SYSDBA'));
    const wPass = (await ask(rl, 'Password for ' + wUser, 'masterkey'));
    // تأكيد الاتصال
    try { const t = await attach({ host: c.dbHost, port: c.dbPort, database: c.dbPath, user: wUser, password: wPass }); await detach(t); }
    catch (e) { console.log('\n[STOP] Could not connect with that user: ' + fbErr(e) + '\nNothing changed.'); return; }
    saveCfg({ ...c, orgaWrite: true, dbWriteUser: wUser, dbWritePass: wPass });
    console.log('\nOK - Orga write is ON. From now on the scheduled sync also writes queued purchase invoices into Orga.');
    console.log('To turn it off later: run.bat writesetup  then answer n.');
  } finally { rl.close && rl.close(); }
}

/* ---------- إعداد أول مرة ---------- */
function lineReader() {
  const rl = require('readline').createInterface({ input: process.stdin, output: process.stdout, terminal: !!process.stdin.isTTY });
  const buf = [], wait = []; let closed = false;
  rl.on('line', l => { if (wait.length) wait.shift()(l); else buf.push(l); });
  rl.on('close', () => { closed = true; while (wait.length) wait.shift()(''); });
  return { next: () => buf.length ? Promise.resolve(buf.shift()) : closed ? Promise.resolve('') : new Promise(r => wait.push(r)), close: () => rl.close() };
}
async function ask(rl, qs, def) { process.stdout.write(qs + (def ? ` [${def}]` : '') + ': '); const a = await rl.next(); if (!process.stdin.isTTY) process.stdout.write('\n'); return (a || '').trim() || def || ''; }
const clean = v => String(v || '').normalize('NFKC').replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff\s]/g, '');
async function setup() {
  const rl = lineReader();
  console.log('\n=== Mizan <- Orga link setup ===\n');
  let url = '';
  for (;;) {
    url = clean(await ask(rl, 'Mizan URL', 'https://mizan-ylmi.onrender.com')).replace(/\/+$/, '');
    if (/^https:\/\/[^/]+$/.test(url) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(url)) break;
    console.log('  The URL must look like https://mizan-ylmi.onrender.com - try again');
  }
  let token = '';
  for (let k = 1; ; k++) {
    // اللصق في الـ console ساعات بيجيب حروف مخفية — بناخد المفتاح بس من اللي اتلصق
    const raw = clean(await ask(rl, 'Sync key (Mizan > Settings > Orga link) - paste with right-click'));
    const m = /mzo_[A-Za-z0-9_-]{20,100}/.exec(raw);
    if (!m) { console.log('  That is not a sync key. It starts with mzo_ - copy it again from Mizan.'); }
    else {
      token = m[0];
      try { await api({ url, token }, '/api/orga/ping', {}); console.log('  OK - Mizan accepted the key'); break; }
      catch (e) { console.log('  ' + (e.status === 401 ? 'Mizan rejected this key (wrong, or a newer key was created / key revoked). Use the LATEST key from Mizan.' : 'Cannot reach Mizan: ' + e.message)); }
    }
    if (k >= 5) throw new Error('Setup stopped - no valid sync key');
  }
  // الملف ممكن يكون على الجهاز ده، أو على جهاز تاني في الشبكة (\\M1\orga_soft\DATA)
  // Firebird مابيفتحش ملفات من مشاركة شبكة: لازم نكلّم سيرفر Firebird اللي على الجهاز صاحب الملف، بمسار الملف عنده هو
  let dbPath = '', dbHost = '127.0.0.1', cands = [];
  for (let k = 1; ; k++) {
    let v = (await ask(rl, 'ORGA.GDB location (file path, folder, or network path like \\\\M1\\orga_soft\\DATA)', 'C:\\orga_soft\\DATA\\ORGA.GDB')).trim().replace(/^["']+|["']+$/g, '').trim();
    const unc = /^\\\\([^\\]+)\\([^\\]+)(\\.*)?$/.exec(v);
    if (unc) {
      dbHost = unc[1]; let rest = (unc[3] || '').replace(/\\+$/, '');
      if (!/\.(gdb|fdb)$/i.test(rest)) {
        let f = 'ORGA.GDB'; try { f = fs.readdirSync(v).find(n => /^orga\.gdb$/i.test(n)) || fs.readdirSync(v).find(n => /\.(gdb|fdb)$/i.test(n)) || f; } catch (e) {}
        rest += '\\' + f;
      }
      for (const d of 'CDEFGH') cands.push(`${d}:\\${unc[2]}${rest}`, `${d}:${rest}`);
      console.log(`  Network path: will connect to the Firebird server on ${dbHost} and look for the file there.`);
      break;
    }
    dbPath = v;
    try {
      if (fs.statSync(dbPath).isDirectory()) {
        const f = fs.readdirSync(dbPath).find(n => /^orga\.gdb$/i.test(n)) || fs.readdirSync(dbPath).find(n => /\.(gdb|fdb)$/i.test(n));
        if (f) { dbPath = path.join(dbPath, f); console.log('  Found: ' + dbPath); break; }
        console.log('  That is a folder with no ORGA.GDB inside.');
      } else break;
    } catch (e) {
      console.log('  Not found on this computer: ' + dbPath);
      if (/^[A-Za-z]:/.test(dbPath)) { const ok = (await ask(rl, '  Is this the path on ANOTHER computer (the Firebird server)? y/n', 'n')).toLowerCase(); if (ok.startsWith('y')) { dbHost = ''; break; } }
    }
    if (k >= 5) throw new Error('Setup stopped - ORGA.GDB not found');
  }
  dbHost = clean(await ask(rl, 'Firebird server (computer name or IP that has ORGA.GDB)', dbHost || 'M1'));
  const dbPort = +(clean(await ask(rl, 'Firebird port', '3050'))) || 3050;
  console.log('\nA read-only Firebird user named ' + RO_USER + ' will be created.');
  console.log('The SYSDBA password is needed once for that (it is NOT saved).');
  const sysPass = (await ask(rl, 'SYSDBA password', 'masterkey')).trim();
  if (cands.length) {
    // بندوّر على مسار الملف على السيرفر: نجرّب الأماكن المتوقعة (C:\orga_soft\DATA\ORGA.GDB, D:\...)
    for (const cnd of cands) {
      try { const t = await attach({ host: dbHost, port: dbPort, database: cnd, user: 'SYSDBA', password: sysPass }); await detach(t); dbPath = cnd; console.log(`  Found on ${dbHost}: ${dbPath}`); break; }
      catch (e) { const m = String(e.message || e); if (!/I\/O error|open|No such|unavailable|not found/i.test(m)) throw new Error(fbErr(e) + (/ECONN|ETIMEDOUT|EHOSTUNREACH|ENOTFOUND/i.test(m) ? ` - check that ${dbHost} is on, Firebird runs there, and port ${dbPort} is allowed in its firewall` : '')); }
    }
    while (!dbPath) {
      console.log(`  Could not find the file automatically on ${dbHost}.`);
      console.log(`  On ${dbHost}: right-click the shared folder > Properties to see its real path (for example D:\\orga_soft\\DATA).`);
      dbPath = (await ask(rl, `Path of ORGA.GDB ON ${dbHost} (e.g. D:\\orga_soft\\DATA\\ORGA.GDB)`)).trim().replace(/^["']+|["']+$/g, '').trim();
      if (dbPath && !/\.(gdb|fdb)$/i.test(dbPath)) dbPath = dbPath.replace(/\\+$/, '') + '\\ORGA.GDB';
      if (!dbPath) throw new Error('Setup stopped - no database path');
    }
  }
  rl.close();
  const roPass = crypto.randomBytes(12).toString('base64url').replace(/[^A-Za-z0-9]/g, 'x').slice(0, 8); // Firebird 2.5 بياخد أول 8 حروف
  let sys;
  try { sys = await attach({ host: dbHost, port: dbPort, database: dbPath, user: 'SYSDBA', password: sysPass }); }
  catch (e) { throw new Error(fbErr(e)); }
  let dbUser = RO_USER, dbPass = roPass;
  try {
    try { await q(sys, `DROP USER ${RO_USER}`); } catch (e) {}
    await q(sys, `CREATE USER ${RO_USER} PASSWORD '${roPass}'`);
    for (const t of TABLES) { try { await q(sys, `GRANT SELECT ON "${t}" TO USER ${RO_USER}`); } catch (e) { console.log('  (note) ' + t + ': ' + e.message); } }
  } catch (e) {
    // سيرفر قديم مايقبلش CREATE USER: بنكمل بـ SYSDBA بس كل القراءة بتتم في transaction «قراءة بس»
    console.log('WARNING: could not create the read-only user (' + e.message + ') - SYSDBA will be used in read-only transactions');
    dbUser = 'SYSDBA'; dbPass = sysPass;
  } finally { await detach(sys); }
  // تأكيد إن المستخدم قراءة بس فعلًا: محاولة كتابة لازم تترفض
  const ro = await attach({ host: dbHost, port: dbPort, database: dbPath, user: dbUser, password: dbPass });
  if (dbUser === RO_USER) try {
    const tx = await new Promise((res, rej) => ro.transaction(fb.ISOLATION_READ_COMMITTED, (e, t) => e ? rej(e) : res(t)));
    let wrote = false;
    try { await q(tx, `UPDATE "PRODUCTS" SET "PROD_ID"="PROD_ID" WHERE "PROD_ID"=(SELECT MIN("PROD_ID") FROM "PRODUCTS")`); wrote = true; } catch (e) {}
    await new Promise(res => tx.rollback(() => res()));
    if (wrote) throw new Error('The Firebird user can write - setup stopped');
    console.log('OK - read-only user created, and writing is blocked');
  } finally { await detach(ro); } else await detach(ro);
  const c = { url, token, dbPath, dbHost, dbPort, dbUser, dbPass };
  const T = await readOrga(c).catch(e => { throw new Error(fbErr(e)); });
  console.log(`OK - reading works: ${T.PRODUCTS.length} products, ${T.INVOICES_H.length} sale invoices`);
  // ملف أورجا اتغيّر → ذاكرة المزامنة القديمة متخصّش الملف الجديد: بنبدأ مقارنة كاملة
  try { const o = JSON.parse(fs.readFileSync(CFG, 'utf8')); if (o.dbPath !== c.dbPath || o.dbHost !== c.dbHost) { fs.unlinkSync(STATE); console.log('  Database changed - the next sync re-checks everything'); } } catch (e) {}
  saveCfg(c);
  const r = await api(loadCfg(), '/api/orga/ping', {});
  console.log('OK - settings saved encrypted on this computer.\n');
  return r;
}

/* ---------- main ---------- */
(async () => {
  const cmd = process.argv[2] || 'sync';
  try {
    if (cmd === 'setup') { await setup(); return; }
    if (cmd === 'writetest') { await writeTest(process.argv[3], process.argv.includes('--commit')); return; }
    if (cmd === 'writesetup') { await writeSetup(); return; }
    if (cmd === 'reset') { try { fs.unlinkSync(STATE); } catch (e) {} log('Sync state cleared - next run compares everything'); return; }
    // قفل علشان مزامنتين ميشتغلوش مع بعض
    try { const st = fs.statSync(LOCK); if (Date.now() - st.mtimeMs < 30 * 60e3) { log('Another sync is running - skipping this run'); return; } } catch (e) {}
    fs.writeFileSync(LOCK, String(process.pid));
    try { await sync(cmd === 'test'); } finally { try { fs.unlinkSync(LOCK); } catch (e) {} }
  } catch (e) {
    log('ERROR: ' + (e.message || e));
    process.exitCode = 1;
  }
})();
