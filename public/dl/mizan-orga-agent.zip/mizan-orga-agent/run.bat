@echo off
cd /d "%~dp0"
call "%~dp0_node.bat"
if not defined NODE exit /b 1
"%NODE%" agent.js %*
