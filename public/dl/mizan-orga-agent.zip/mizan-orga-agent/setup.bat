@echo off
title Mizan - Orga link setup
cd /d "%~dp0"
net session >nul 2>&1 || (echo Please right-click setup.bat and choose "Run as administrator". & echo. & pause & exit /b 1)
call "%~dp0_node.bat"
if not defined NODE (
  echo Node.js is not installed - installing it now...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  call "%~dp0_node.bat"
)
if not defined NODE (
  echo.
  echo Could not install Node.js automatically. Install the LTS version from https://nodejs.org then run setup.bat again.
  pause & exit /b 1
)
"%NODE%" agent.js setup || (echo. & echo Setup did not finish. & pause & exit /b 1)
echo.
echo Creating the scheduled task "Mizan Orga Sync" (every 5 minutes, runs without login)...
schtasks /Create /TN "Mizan Orga Sync" /SC MINUTE /MO 5 /TR "\"%~dp0run.bat\"" /RU SYSTEM /RL HIGHEST /F >nul || (echo Could not create the scheduled task. & pause & exit /b 1)
echo OK. Running the first sync now (can take a minute)...
call "%~dp0run.bat"
echo.
echo Done! Check the status in Mizan: Settings ^> Orga link
echo Log file: %~dp0logs\agent.log
pause
