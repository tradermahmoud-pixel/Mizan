@echo off
chcp 65001 >nul
title Mizan - Orga link setup
cd /d "%~dp0"
net session >nul 2>&1 || (echo لازم تشغّل الملف ده "Run as administrator" & echo. & pause & exit /b 1)
call "%~dp0_node.bat"
if not defined NODE (
  echo Node.js مش موجود على الجهاز — هنسطّبه دلوقتي...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  call "%~dp0_node.bat"
)
if not defined NODE (
  echo.
  echo مقدرناش نسطّب Node.js تلقائي. نزّله من https://nodejs.org ^(نسخة LTS^) وبعدين شغّل setup.bat تاني.
  pause & exit /b 1
)
"%NODE%" agent.js setup || (pause & exit /b 1)
echo.
echo بنعمل مهمة مجدولة بتزامن كل 5 دقايق...
schtasks /Create /TN "Mizan Orga Sync" /SC MINUTE /MO 5 /TR "\"%~dp0run.bat\"" /RU SYSTEM /RL HIGHEST /F >nul || (echo فشل إنشاء المهمة المجدولة & pause & exit /b 1)
echo ✓ اتعملت. أول مزامنة بتبدأ دلوقتي (ممكن تاخد دقيقة)...
call "%~dp0run.bat"
echo.
echo خلاص! تقدر تتابع حالة الربط من ميزان: الإعدادات ← ربط أورجا
echo السجل: %~dp0logs\agent.log
pause
