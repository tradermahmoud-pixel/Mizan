@echo off
cd /d "%~dp0"
title Mizan Orga - Fast Writer (keep open)
if not exist "%~dp0config.json" (
  echo This folder has no config.json - you are in the WRONG folder.
  echo Put watch.bat in the same folder as the run.bat that works, then try again.
  pause
  exit /b 1
)
call "%~dp0_node.bat"
if not defined NODE (echo Node.js not found. Run setup.bat first. & pause & exit /b 1)
echo Starting the fast writer... keep this window open (you can MINIMIZE it).
echo Close it to stop. It writes queued purchases to Orga every ~12 seconds.
echo.
"%NODE%" agent.js watch
echo.
echo (The writer stopped.)
pause
