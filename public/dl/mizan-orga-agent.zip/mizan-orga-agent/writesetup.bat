@echo off
cd /d "%~dp0"
call "%~dp0_node.bat"
if not defined NODE (echo Node.js not found - run setup.bat first & pause & exit /b 1)
"%NODE%" agent.js writesetup
pause
