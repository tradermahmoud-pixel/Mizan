@echo off
chcp 65001 >nul
cd /d "%~dp0"
call "%~dp0_node.bat"
if not defined NODE (echo Node.js not found - run setup.bat first & pause & exit /b 1)
set "T=%~1"
if "%T%"=="" set "T=C:\ORGA_TEST\DATA\ORGA.GDB"
echo Safe write test on TEST db: %T%
echo (add  --commit  to actually keep one open invoice; without it, it rolls back)
"%NODE%" agent.js writetest "%T%" %2 %3
pause
