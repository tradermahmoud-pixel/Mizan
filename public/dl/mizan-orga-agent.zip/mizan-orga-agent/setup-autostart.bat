@echo off
cd /d "%~dp0"
if not exist "%~dp0config.json" (echo Run this from the agent folder that has config.json. & pause & exit /b 1)
icacls "%~dp0config.json" /grant *S-1-5-32-545:R >nul 2>&1
if %errorlevel% neq 0 (
  if "%~1"=="elevated" (
    echo Could not set read permission on config.json even as administrator.
    pause
    exit /b 1
  )
  echo Asking for administrator permission (one time)...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList 'elevated' -Verb RunAs"
  exit /b
)
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $p=[Environment]::GetFolderPath('Startup')+'\MizanFastWriter.lnk'; $s=$w.CreateShortcut($p); $s.TargetPath='%~dp0watch.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"
if %errorlevel% neq 0 (echo Could not create the Startup shortcut. & pause & exit /b 1)
echo.
echo Done. The fast writer now starts automatically (minimized) every time you log in.
echo You do NOT need to run anything after a restart.
echo (You can close any writer window; it will come back on next login.)
pause
