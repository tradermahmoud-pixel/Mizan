@echo off
cd /d "%~dp0"
if not exist "%~dp0config.json" (
  echo This folder has no config.json. Put setup-autostart.bat in the agent folder and try again.
  echo.
  pause
  exit /b 1
)
echo === Step 1: allow your user to read config.json ===
icacls "%~dp0config.json" /grant *S-1-5-32-545:R
echo.
echo   ^(If it says "Access is denied" above: close this, then RIGHT-CLICK
echo    setup-autostart.bat and choose "Run as administrator", and run it again.^)
echo.
echo === Step 2: add the fast writer to Startup ^(auto-start at login^) ===
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $p=[Environment]::GetFolderPath('Startup')+'\MizanFastWriter.lnk'; $s=$w.CreateShortcut($p); $s.TargetPath='%~dp0watch.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save(); Write-Host ('Startup shortcut created at: ' + $p)"
echo.
echo === Done ===
echo If both steps above show success, the writer will start automatically
echo ^(minimized^) every time you log in - nothing to run after a restart.
echo.
pause
