@echo off
cd /d "%~dp0"
net session >nul 2>&1 || (echo Please right-click uninstall.bat and choose "Run as administrator". & pause & exit /b 1)
schtasks /Delete /TN "Mizan Orga Sync" /F
del /q config.json state.json sync.lock 2>nul
echo Removed from this computer. Also revoke the key in Mizan: Settings ^> Orga link ^> Revoke.
pause
