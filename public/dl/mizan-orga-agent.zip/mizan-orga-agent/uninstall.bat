@echo off
chcp 65001 >nul
cd /d "%~dp0"
net session >nul 2>&1 || (echo لازم تشغّل الملف ده "Run as administrator" & pause & exit /b 1)
schtasks /Delete /TN "Mizan Orga Sync" /F
del /q config.json state.json sync.lock 2>nul
echo اتشال الربط من الجهاز ده. ^(متنساش تلغي المفتاح من ميزان: الإعدادات ← ربط أورجا^)
pause
