@echo off
cd /d "%~dp0"
if not exist "%~dp0run.bat" (
  echo Put fastwrites.bat INSIDE the Mizan agent folder, next to run.bat.
  pause
  exit /b 1
)
echo Creating the fast write task (runs as you, every minute, while you are logged in)...
echo.
schtasks /Create /TN "Mizan Orga Write" /SC MINUTE /MO 1 /TR "\"%~dp0run.bat\" outbox" /F
echo.
echo If you see SUCCESS above, you are done. Queued purchases now write within about a minute.
echo If you see an error, send me a screenshot of this whole window.
pause
