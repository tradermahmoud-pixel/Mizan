@echo off
cd /d "%~dp0"
if not exist "%~dp0run.bat" (
  echo run.bat not found here. Put fastwrites.bat INSIDE the Mizan agent folder, next to run.bat.
  pause
  exit /b 1
)
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Asking for administrator permission...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
schtasks /Create /TN "Mizan Orga Write" /SC MINUTE /MO 1 /TR "\"%~dp0run.bat\" outbox" /RU SYSTEM /RL HIGHEST /F
if %errorlevel% equ 0 (
  echo.
  echo OK - fast write task created. Queued purchases write within about a minute.
) else (
  echo.
  echo Could not create the task. Allow the administrator prompt and try again.
)
pause
