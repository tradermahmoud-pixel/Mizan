@echo off
cd /d "%~dp0"
if not exist "%~dp0run.bat" (
  echo run.bat not found here. Put fastwrites.bat INSIDE the Mizan agent folder, next to run.bat.
  pause
  exit /b 1
)
schtasks /Create /TN "Mizan Orga Write" /SC MINUTE /MO 1 /TR "\"%~dp0run.bat\" outbox" /RU SYSTEM /RL HIGHEST /F 2>nul
if %errorlevel% equ 0 (
  echo.
  echo OK - fast write task created. Queued purchases write within about a minute.
  pause
  exit /b 0
)
if "%~1"=="elevated" (
  echo.
  echo Could not create the task even as administrator. Send me a screenshot.
  pause
  exit /b 1
)
echo Asking for administrator permission...
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList 'elevated' -Verb RunAs"
exit /b
