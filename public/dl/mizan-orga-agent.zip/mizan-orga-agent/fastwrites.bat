@echo off
net session 1>NUL 2>NUL || (echo Right-click this file and choose "Run as administrator". ^& pause ^& exit /b 1)
schtasks /Create /TN "Mizan Orga Write" /SC MINUTE /MO 1 /TR "\"%~dp0run.bat\" outbox" /RU SYSTEM /RL HIGHEST /F
if errorlevel 1 (echo Could not create the task. ^& pause ^& exit /b 1)
echo OK - fast write task created: queued purchases are written within about a minute.
pause
