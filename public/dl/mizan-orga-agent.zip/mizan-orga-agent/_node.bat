@echo off
rem بيدوّر على Node.js: النسخة اللي جنب البرنامج، أو المتسطّبة على الجهاز
set "NODE=%~dp0node\node.exe"
if exist "%NODE%" goto :eof
set "NODE="
for %%N in (node.exe) do if not "%%~$PATH:N"=="" set "NODE=%%~$PATH:N"
if defined NODE goto :eof
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE=%ProgramFiles%\nodejs\node.exe"
