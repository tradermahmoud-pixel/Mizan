@echo off
rem Find Node.js: bundled copy, PATH, or the default install folder
set "NODE=%~dp0node\node.exe"
if exist "%NODE%" goto :eof
set "NODE="
for %%N in (node.exe) do if not "%%~$PATH:N"=="" set "NODE=%%~$PATH:N"
if defined NODE goto :eof
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE=%ProgramFiles%\nodejs\node.exe"
